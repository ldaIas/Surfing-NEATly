# Fragsurf Character Controller

http://fragsurf.net/
https://discord.gg/eexZPMC

Bhop and surfing physics from Counter Strike ported to Unity3d.

Add scripts to your Unity Project and attach the Surf Character Controller component.

Be sure to set Movement.SurfPhysics.GroundLayerMask if your ground colliders are not assigned to the Default layer.

This repo will not be maintained

Some logic was pulled from here:
https://github.com/ValveSoftware/source-sdk-2013/blob/master/mp/src/game/shared/gamemovement.cpp
