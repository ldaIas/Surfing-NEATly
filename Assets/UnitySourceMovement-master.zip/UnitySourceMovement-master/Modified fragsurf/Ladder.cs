﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ladder : MonoBehaviour {

    // Empty class for defining objects as ladders
    // Probably inefficient, but I didn't want to use tags or layers

}
